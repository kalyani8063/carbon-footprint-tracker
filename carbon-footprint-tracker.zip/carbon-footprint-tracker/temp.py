from worldometer.world import WorldCounters
wc = WorldCounters()
print(wc.environment.co2_emissions_this_year)